[EN]

Mantis-a templates - Free XHTML/CSS website templates for download

http://www.mantisatemplates.com/

--------------------------------------------------
 Terms of use
--------------------------------------------------

1. The templates are free to use for non-commercial and commercial purposes.
2. It is prohibited use templates for unlawful purposes.
3. The necessary condition for using the templates is to leave a backlink in a footer of every template. 
   Do you want to remove a backlink? ==> Charge for removing of backlinks [http://www.mantisatemplates.com/support.php#charge-for-remove]
   It is prohibited to modify the backlinks (color, font size, �).
4. The backlinks must be perceivable.
5. You can redistribute the templates, but only in a non-modified form.
   You have to redistribute them for free!
6. By downloading any of the templates, you agree to observe all aforesaid conditions.


Enjoy ;-)


[CS]

Mantis-a templates - XHTML/CSS �ablony webov�ch str�nek ke sta�en� zdarma

http://www.mantisatemplates.com/cz/

--------------------------------------------------
 Podm�nky u��v�n�
--------------------------------------------------

1. �ablony jsou poskytov�ny zdarma pro nekomer�n� i komer�n� pou�it�.
2. Je zak�z�no pou��vat �ablony k nez�konn�m ��el�m.
3. Nezbytnou podm�nkou u�it� �ablon je ponech�n� zp�tn�ch odkaz� v pati�ce ka�d� z �ablon. 
   Chcete zp�tn� odkazy odstranit? ==> Poplatek za odstran�n� odkaz� [http://www.mantisatemplates.com/support.php#poplatek-za-odstraneni-odkazu]
   Je zak�z�no zp�tn� odkazy jakkoli m�nit (color, font size, �).
4. Zp�tn� odkazy mus� b�t �iteln�.
5. �ablony m��ete d�le ���it, av�ak pouze v nezm�n�n� form�.
   �ablony mus� b�t poskytov�ny op�t zdarma!
6. Sta�en�m kter�koli �ablony/�ablon souhlas�te s dodr�ov�n�m v�ech v��e uveden�ch podm�nek.


Enjoy ;-)